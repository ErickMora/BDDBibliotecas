﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaBiblioteca.Usuario
{
    public partial class Usuario : Form
    {
        private ConexionSQL conexionSql;
        private string tipo;
        private string id;

        public Usuario(string tipo, string id)
        {
            InitializeComponent();
            conexionSql = new ConexionSQL();
            this.CenterToScreen();
            MaximizeBox = false;
            MinimizeBox = false;
            this.tipo = tipo;
            this.id = id;
            //initGridView();
           initComponents();
        }
       
        private void initComponents()
        {
            if (tipo.Equals("Modificar"))
            {
                btnGuardar.Text = "Modificar";
                btnGuardar.Width = 85;
                txtID.Enabled = false;
                txtID.Text = id;
                fillForm();
            }
            else if (tipo.Equals("Consultar") || tipo.Equals("Eliminar"))
            {
                btnGuardar.Visible = false;
                btnLimpiar.Visible = false;
                txtNombre.Enabled = false;
                txtID.Enabled = false;

                txtDireccion.Enabled = false;
                txtCedula.Enabled = false;
                txtEmail.Enabled = false;

                txtID.Text = id;
                fillForm();

                tableLayoutPanel1.RowStyles[1].SizeType = SizeType.Percent;
                tableLayoutPanel1.RowStyles[1].Height = 0;

                if (tipo.Equals("Eliminar"))
                {
                    btnLimpiar.Visible = true;
                    btnLimpiar.Text = "Eliminar";
                    btnLimpiar.Width = 85;
                }
            }
        }

        private void fillForm()
        {
            conexionSql.Conectar();
            SqlCommand cmd = new SqlCommand("select * from USUARIO where ID_USUARIO = '" + txtID.Text + "'", conexionSql.getConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                txtNombre.Text = reader.GetString(2);
                txtDireccion.Text = reader.GetString(3);
                txtEmail.Text = reader.GetString(4);
                txtCedula.Text = reader.GetString(5);
                /*if (!reader.IsDBNull(7))
                {
                    dateSalida.Value = reader.GetDateTime(7);
                    checkSalida.Checked = true;
                }
                else
                {
                    dateSalida.Value = DateTime.Today;
                    checkSalida.Checked = false;
                }*/
            }
            conexionSql.Desconectar();
        }

        private void initGridView()
        {
            conexionSql.Conectar();
            string query = "select * from usuario";
            var dataAdapter = new SqlDataAdapter(query, conexionSql.getConnection());
            var ds = new DataTable();
            dataAdapter.Fill(ds);
            BindingSource bsSource = new BindingSource();
            bsSource.DataSource = ds;
            gridViewEstudiante.ReadOnly = true;
            gridViewEstudiante.DataSource = bsSource;
            conexionSql.Desconectar();

            gridViewEstudiante.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
            gridViewEstudiante.Columns[7].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (validarRegistro())
            {
                if (tipo.Equals("Modificar"))
                {
                    guardarUsuario("actualizarUsuario");
                    MessageBox.Show("Usuario modificado con éxito.", "Modificar Usuario", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    btnGuardar.Enabled = false;
                    initGridView();
                }
                else
                {
                    conexionSql.Conectar();
                    SqlCommand cmd = new SqlCommand("select * from V_Usuario where ID_Usuario = '" + txtID.Text + "'", conexionSql.getConnection());
                    SqlDataReader reader = cmd.ExecuteReader();
                    if (!reader.HasRows)
                    {
                        guardarUsuario("registrarUsuario");
                        conexionSql.Desconectar();
                        MessageBox.Show("Usuario registrado con éxito.", "Registrar Usuario", MessageBoxButtons.OK,
                            MessageBoxIcon.Information);
                        btnGuardar.Enabled = false;
                        initGridView();
                    }
                    else
                    {
                        MessageBox.Show("Usuario ya se encuentra registrado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        btnLimpiar.PerformClick();
                        conexionSql.Desconectar();
                    }
                }
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            if (tipo.Equals("Eliminar"))
            {
                if (MessageBox.Show("¿Está seguro que desea eliminar?", "Eliminar", MessageBoxButtons.YesNo,
                        MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    conexionSql.Conectar();
                    SqlCommand comando = new SqlCommand("set xact_abort on begin distributed transaction delete from V_Usuario where ID_Usuario = '" + txtID.Text + "' commit", conexionSql.getConnection());
                    try
                    {
                        comando.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    conexionSql.Desconectar();
                }
            }
            else
            {
                if (tipo.Equals("registro"))
                {
                    txtID.Clear();
                }
                txtNombre.Clear();
                txtDireccion.Clear();
                txtCedula.Clear();
                txtEmail.Clear();
            }
        }

        private bool validarRegistro()
        {
            bool temp = true;

            var err = "Campo Vacio :\n";
            if (string.IsNullOrWhiteSpace(txtID.Text))
                err += "-->ID Usuario\n";
            if (string.IsNullOrWhiteSpace(txtNombre.Text))
                err += "-->Nombre\n";
            if (string.IsNullOrWhiteSpace(txtEmail.Text))
                err += "-->E-Mail\n";
            if (string.IsNullOrWhiteSpace(txtDireccion.Text))
                err += "-->Dirección\n";
            if (string.IsNullOrWhiteSpace(txtCedula.Text))
                err += "-->Cedula\n";

            if (!err.Equals("Campo Vacio :\n"))
            {
                MessageBox.Show(err, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                temp = false;
            }

            return temp;
        }

        private void guardarUsuario(string procedure)
        {
            conexionSql.Conectar();
            SqlCommand cmd = new SqlCommand(procedure, conexionSql.getConnection());
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.Add("@ID_Usuario", SqlDbType.Int).Value = Int32.Parse(txtID.Text);
            cmd.Parameters.Add("@NOMBRE_U", SqlDbType.VarChar).Value = txtNombre.Text;
            cmd.Parameters.Add("@DIRECCION_U", SqlDbType.VarChar).Value = txtDireccion.Text;
            cmd.Parameters.Add("@EMAIL_U", SqlDbType.VarChar).Value = txtEmail.Text;
            cmd.Parameters.Add("@CI_U", SqlDbType.VarChar).Value = txtCedula.Text;
            /*if (checkSalida.Checked)
            {
                cmd.Parameters.Add("@FECHA_SALIDA", SqlDbType.Date).Value = dateSalida.Value;
            }*/
            cmd.Parameters.Add("@NODO", SqlDbType.Int).Value = 1;

            cmd.ExecuteNonQuery();
            conexionSql.Desconectar();
        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkSalida_CheckedChanged(object sender, EventArgs e)
        {
            /*if (checkSalida.Checked)
            {
                dateSalida.Enabled = true;
            }
            else
            {
                dateSalida.Value = DateTime.Today;
                dateSalida.Enabled = false;
            }*/
        }
    }
}
