﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaBiblioteca.Prestamo;
using SistemaBiblioteca.Usuario;
using SistemaBiblioteca.Libro;
using SistemaBiblioteca.Bibliotecario;

namespace SistemaBiblioteca
{
    public partial class PaginaPrincipal : Form
    {
        public PaginaPrincipal()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void registrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Prestamo.Prestamo prestamo = new Prestamo.Prestamo("registro", "");
            prestamo.Text = "Registrar Préstamo";
            prestamo.Show();
        }

        private void consultarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BusquedaPrestamo bc = new BusquedaPrestamo("Consultar");
            bc.Show();
        }

        private void modificarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BusquedaPrestamo bc = new BusquedaPrestamo("Modificar");
            bc.Show();
        }

        private void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BusquedaPrestamo bc = new BusquedaPrestamo("Eliminar");
            bc.Show();
        }

        private void registrarMateriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BusquedaPrestamo bc = new BusquedaPrestamo("materia");
            bc.Show();
        }

        private void registrarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Libro.Libro ma = new Libro.Libro("registro", "");
            ma.Show();
        }

        private void consultarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            BusquedaLibro bm = new BusquedaLibro("Consultar");
            bm.Show();
        }

        private void modificarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            BusquedaLibro bm = new BusquedaLibro("Modificar");
            bm.Show();
        }

        private void eliminarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            BusquedaLibro bm = new BusquedaLibro("Eliminar");
            bm.Show();
        }

        private void registrarEstudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BusquedaLibro bm = new BusquedaLibro("usuario");
            bm.Show();
        }

        private void registrarProfesorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BusquedaLibro bm = new BusquedaLibro("bibliotecario");
            bm.Show();
        }

        private void registrarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Bibliotecario.Bibliotecario p = new Bibliotecario.Bibliotecario("Registro", "");
            p.Show();
        }

        private void consultarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            BusquedaBibliotecario bp = new BusquedaBibliotecario("Consultar");
            bp.Show();
        }

        private void modificarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            BusquedaBibliotecario bp = new BusquedaBibliotecario("Modificar");
            bp.Show();
        }

        private void eliminarToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            BusquedaBibliotecario bp = new BusquedaBibliotecario("Eliminar");
            bp.Show();
        }

        private void registrarToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Usuario.Usuario es = new Usuario.Usuario("Registro", "");
            es.Show();
        }

        private void consultarToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            BusquedaUsuario be = new BusquedaUsuario("Consultar");
            be.Show();
        }

        private void modificarToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            BusquedaUsuario be = new BusquedaUsuario("Modificar");
            be.Show();
        }

        private void eliminarToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            BusquedaUsuario be = new BusquedaUsuario("Eliminar");
            be.Show();
        }

        private void consultarToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            BusquedaBibliotecario bp = new BusquedaBibliotecario("Consultar Nomina");
            bp.Show();
        }

        private void modificarToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            BusquedaBibliotecario bp = new BusquedaBibliotecario("Modificar Nomina");
            bp.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
